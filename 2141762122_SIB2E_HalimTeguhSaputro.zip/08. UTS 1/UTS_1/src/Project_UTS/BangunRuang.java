package Project_UTS;

public class BangunRuang {
    double phi = 3.14;
    double r;
    double s;

    BangunRuang(double r, double phi) {
        this.r = r;
        this.phi = phi;
    }

    BangunRuang(double s1) {
        this.s = s1;
    }

}
